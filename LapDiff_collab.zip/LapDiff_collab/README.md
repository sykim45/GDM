### To run file
```bash
make collab_ours
```