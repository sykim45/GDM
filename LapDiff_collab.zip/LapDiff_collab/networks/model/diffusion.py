import torch
import torch_geometric
import torch.nn.functional as F
import numpy as np
from torch_scatter import scatter_add
from torch_sparse import SparseTensor, fill_diag, matmul, mul, spmm
from torch_sparse import sum as sparsesum
from torch_geometric.utils import add_remaining_self_loops, negative_sampling, sort_edge_index
from torch_geometric.utils.num_nodes import maybe_num_nodes
import math
import scipy.sparse as ssp
from pytorch_indexing import spspmm
import pdb


class GraphDiffusion(torch.nn.Module):
    def __init__(self, data, gnn, predictor=None, args=None):
        super(GraphDiffusion, self).__init__()
        self.gnn = gnn
        self.predictor = predictor
        self.args = args
        self.num_nodes = data.num_nodes
        self.num_feat = data.num_features
        
        self.dropout = args.dropout
        self.hidden_dim = args.hidden
        self.n_steps = args.n_steps
        self.iter = args.iter
        self.batch_size = args.batch_size
        
        if hasattr(data, 'adj_t'):
            self.beta = get_norm_laplacian(data.adj_t, symmetric=False, add_self_loops=False)  # .storage.value()
        else:
            self.beta = get_norm_laplacian(data.edge_index, symmetric=args.symmetric_lap, add_self_loops=False)  # ogbl-ddi
        self.sym = args.symmetric_lap
        self.h = None
        self.feat_weight = args.feat_weight
        self.lap_weight = args.lap_weight
        self.recon = args.recon_weight
        self.feat_weight2 = args.feat_weight2    

    def forward(self, x, adj, edge=None, index=None, negative=False):
        row, col = adj.storage.row(), adj.storage.col()
        deg = scatter_add(adj.storage.value(), col, dim=0, dim_size=x.size(0))
        struct_ = self.structure(deg.unsqueeze(-1))
        if edge is not None:
            row, col = edge[0], edge[1]
        elif index is not None:
            row, col = row[index], col[index]
        edges = struct_[row] * struct_[col]

        h = self.gnn(x, adj)
        output = self.predictor(h[row], h[col])
        self.h = h
        return output

    def diffusion(self, x, adj, target_index=None):
        diffusion_loss = 0
        t = self.n_steps
        
        adjs, drop_masks = self.diffusion_struct(adj, time_step=t)
        lap = get_norm_laplacian(adj, symmetric=False, add_self_loops=False, num_nodes=self.num_nodes)
        if self.iter:
            diffusion_loss = 0
            for i in reversed(range(1, self.n_steps)):
                xt = self.diffusion_feature(input=x, t=i)
                adj_k = adjs[i]
                mask_k = drop_masks[i]

                gnn_output = self.gnn(xt, adj_k)
                
                feat_loss = F.mse_loss(gnn_output, self.diffusion_feature(x, t=i-1))
                
                target_index = self.mask2_idx_(edge_mask=mask_k, remain=False)
                perm = torch.randperm(target_index.size(0))[:int(target_index.size(0) )]
                lap_t = get_norm_laplacian(adjs[i-1], symmetric=False, add_self_loops=False, num_nodes=self.num_nodes)
                
                diff_loss = F.mse_loss(input=output.squeeze(), target=lap.storage.value()[perm]-lap_t.storage.value()[perm])

                diffusion_loss += (self.feat_weight * feat_loss) + (self.lap_weight * diff_loss)

            x1 = self.diffusion_feature(input=x, t=1)
            adj_1 = adjs[1]            
            mask_1 = drop_masks[1]
            
            h = self.gnn(x1, adj_1)
            feat_loss_01 = F.mse_loss(input=h, target=x)

            target_index_1 = self.mask2_idx_(edge_mask=mask_1, remain=False)
            perm1 = torch.randperm(target_index_1.size(0))[:int(self.batch_size * 1.0)]
            output_01 = self.predictor(h[adj.storage.row()[target_index_1[perm1]]],h[adj.storage.col()[target_index_1[perm1]]])
            recon_output = output_01
            neg_edge = torch_geometric.utils.negative_sampling(edge_index=torch.stack([adj.storage.row(),adj.storage.col()],dim=0), 
                                                               num_neg_samples=int(self.batch_size * 1.0))

            recon_neg = self.predictor(h[neg_edge[0]], h[neg_edge[1]])
            recon_loss = -torch.log(recon_output + 1e-15).mean() + -torch.log(1 - recon_neg + 1e-15).mean()
            diffusion_loss += (recon_loss * self.recon) + (feat_loss_01 * self.feat_weight2)
            
        else:
            xt = self.diffusion_feature(input=x, t=t)
            adj_k = adjs[t]
            mask_k = drop_masks[t]
            
            lap_t = get_norm_laplacian(adjs[t-1], symmetric=False, add_self_loops=False, num_nodes=self.num_nodes)
            lap = get_norm_laplacian(adj, symmetric=False, add_self_loops=False, num_nodes=self.num_nodes)
            target_index = self.mask2_idx_(edge_mask=mask_k, remain=False)
            perm = torch.randperm(target_index.size(0))[:int(target_index.size(0) * 0.3)] 

            gnn_output = self.gnn(xt, adj_k)
            output = self.predictor(gnn_output[adj.storage.row()[perm]], gnn_output[adj.storage.col()[perm]])
            self.h = gnn_output
            feat_loss = self.feat_weight * F.mse_loss(input=self.h, target=self.diffusion_feature(x, 1))
            
            diff_loss = self.lap_weight * F.mse_loss(input=output.squeeze(), target=lap.storage.value()[perm]-lap_t.storage.value()[perm])

            diffusion_loss += diff_loss + feat_loss

            # >>>>>>>>>>>>>>>> A1 -> A0 Reconstrubtion >>>>>>>>>>>
            x1 = self.diffusion_feature(x, t=1)
            adj_1 = adjs[1]            
            mask_1 = drop_masks[1]
            
            h = self.gnn(x1, adj_1)
            feat_loss_01 = F.mse_loss(input=h, target=x)

            target_index_1 = self.mask2_idx_(edge_mask=mask_1, remain=False)
            perm1 = torch.randperm(target_index_1.size(0))[:int(self.batch_size * 1.0)]
            output_01 = self.predictor(h[adj.storage.row()[target_index_1[perm1]]],h[adj.storage.col()[target_index_1[perm1]]])
            recon_output = output_01
            neg_edge = torch_geometric.utils.negative_sampling(edge_index=torch.stack([adj.storage.row(),adj.storage.col()],dim=0), 
                                                               num_neg_samples=int(self.batch_size * 1.0))

            recon_neg = self.predictor(h[neg_edge[0]], h[neg_edge[1]])
            recon_loss = -torch.log(recon_output + 1e-15).mean() + -torch.log(1 - recon_neg + 1e-15).mean()

            diffusion_loss += (recon_loss * self.recon) + (feat_loss_01 * self.feat_weight2) #1, 0.25 good
            
        del adjs, drop_masks
        return diffusion_loss
    
    def reset_parameters(self):
        self.gnn.reset_parameters()
        self.predictor.reset_parameters()
        self.h = None
        
    def weight_reset(self, m):
        if isinstance(m, torch.nn.Linear):
            m.reset_parameters()

    
    def diffusion_feature(self, input, t, lap=None):
        if lap is None:
            lap = self.beta
        message = matmul(lap, input)
        if t > 1:
            for ti in range(t-1):
                message = matmul(lap, message)
        message = message + input
        return message
    
    def diffusion_struct(self, adj, time_step):
        t = time_step
        prev_adj = {}
        drop_masks = {}
        for k in range(0,t):
            tmp_p = ((k+1) / t) 
            if k == 0:
                subgraph_k, sub_weight_k, drop_mask_k = self.spanning_subgraph_(adj, p=tmp_p, edge_weight='uni')
                #subgraph_k, sub_weight_k, drop_mask_k = self.spanning_subgraph_degree_(adj, i=k)
            else:
                subgraph_k, sub_weight_k, drop_mask_k = self.spanning_subgraph_(subgraph_k, p=tmp_p, edge_weight='uni')
                #subgraph_k, sub_weight_k, drop_mask_k = self.spanning_subgraph_degree_(prev_adj[k], i=k)
            prev_adj[k+1] = subgraph_k.to(adj.device())
            drop_masks[k+1] = drop_mask_k.to(adj.device())
        return prev_adj, drop_masks

    def mask2_idx_(self, edge_mask, remain=True, force_undirected=False):
        val = 1 if remain else 0
        if force_undirected:
            return (edge_mask==val).nonzero().repeat((2,1)).squeeze()
        else:
            return (edge_mask==val).nonzero().squeeze()


    def spanning_subgraph_(self, edge_index, p=0.0, edge_weight='multi', force_undirected=False, training=True):
        if p < 0.0 or p > 1.0:
            raise ValueError("Dropout Probability should be between 0 and 1, but got p={}".format(p))
        
        if not training or p == 0.0:
            if isinstance(edge_index, SparseTensor):
                row_size = edge_index.storage.row().size(0)
            else:
                row_size = edge_index.size(1)
            edge_mask = torch.ones(row_size, dtype=torch.bool)
            #edge_mask = torch.tensor(range(row_size))
            if edge_weight == 'multi':
                return edge_index, edge_index.storage.value(), edge_mask
            else:
                return edge_index, torch.ones(row_size), edge_mask
        
        if p == 1.0:
            if isinstance(edge_index, SparseTensor):
                row_size = edge_index.storage.row().size(0)
            else:
                row_size = edge_index.size(1)
            edge_attr = torch.zeros(row_size)
            edge_mask = torch.zeros(row_size, dtype=torch.bool)
            return edge_index, edge_attr, edge_mask

        if isinstance(edge_index, SparseTensor):
            row, col = edge_index.storage.row(), edge_index.storage.col()
            attr = edge_index.storage.value()
        else:
            row, col = edge_index
            attr = edge_index.edge_weight
        if edge_weight=='uni':
            attr = torch.ones(row.size(0), device=row.device)
            
        edge_mask = torch.rand(row.size(0), device=row.device) >= p

        if force_undirected:
            edge_mask[row > col] = False
            sampled_index = torch.stack(
                [torch.cat([row, col], dim=0),
                torch.cat([col, row], dim=0)],dim=0)
            sampled_attr = torch.cat([attr * edge_mask.float(), attr * edge_mask.float()], dim=0)

        else:
            sampled_index = torch.stack([row, col], dim=0)
            sampled_attr = attr * edge_mask.float()

        if isinstance(edge_index, SparseTensor):
            #sparse_size = int(max(sampled_index[0].max(), sampled_index[1].max())) + 1
            sparse_size = self.num_nodes
            sampled_index = SparseTensor(row=sampled_index[0], col=sampled_index[1], value=sampled_attr, sparse_sizes=(sparse_size, sparse_size))
        return sampled_index, sampled_attr, edge_mask


class OurLearner(torch.nn.Module):
    def __init__(self, in_feat, h_dim, out_feat, num_layers, dropout, dataset):
        super(OurLearner, self).__init__()
        self.nn = torch.nn.ModuleList()

        if num_layers == 1:
            self.nn.append(torch_geometric.nn.dense.Linear(in_channels=in_feat, out_channels=out_feat, bias=True, weight_initializer='glorot'))
        else:
            self.nn.append(torch_geometric.nn.dense.Linear(in_channels=in_feat, out_channels=h_dim, bias=True, weight_initializer='glorot'))
            for _ in range(num_layers-2):
                self.nn.append(torch_geometric.nn.dense.Linear(in_channels=h_dim, out_channels=h_dim, bias=True, weight_initializer='glorot'))
            self.nn.append(torch_geometric.nn.dense.Linear(in_channels=h_dim, out_channels=out_feat, bias=True, weight_initializer='glorot'))
            
        self.latent = torch.nn.Parameter(torch.empty(dataset.edge_index.size(1))).float()

        
    def forward(self, x, adj, edge_weight=None):
        prop = torch_geometric.utils.spmm(adj, x) 
        for lin in self.nn[:-1]:
            prop = lin(prop)
            prop = F.relu(prop)
            prop = spmm(index=torch.stack([adj.storage.row(),adj.storage.col()]),value=self.latent, matrix=prop,m=x.size(0),n=x.size(0))
        out = self.nn[-1](prop)
        return out
    
    def reset_parameters(self):
        for lin in self.nn:
            lin.reset_parameters()
        torch_geometric.nn.inits.zeros(self.latent)

    def get_params(self):
        params = []
        for pp in list(self.parameters()):
            params.append(pp.view(-1))
        return torch.cat(params)

    def set_params(self, new_params):
        assert new_params.size() == self.get_params().size()
        progress = 0
        for pp in list(self.parameters()):
            cand_params = new_params[progress: progress +
                torch.tensor(pp.size()).prod()].view(pp.size())
            progress += torch.tensor(pp.size()).prod()
            pp.data = cand_params

