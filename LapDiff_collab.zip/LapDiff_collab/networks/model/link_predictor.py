import torch
import torch.nn.functional as F
from torch.nn import Parameter


class LinkPredictor(torch.nn.Module):
    def __init__(self, in_channels, hidden_channels, out_channels, num_layers,
                 dropout=0.5):
        super(LinkPredictor, self).__init__()
        self.hidden = hidden_channels
        self.lins = torch.nn.ModuleList()
        if num_layers == 1:
            self.lins.append(torch.nn.Linear(in_channels, out_channels))
        else:
            self.lins.append(torch.nn.Linear(in_channels, hidden_channels))
            for _ in range(num_layers - 2):
                self.lins.append(torch.nn.Linear(hidden_channels, hidden_channels))
            self.lins.append(torch.nn.Linear(hidden_channels, out_channels))

        self.dropout = dropout

    def reset_parameters(self):
        for lin in self.lins:
            lin.reset_parameters()
            
    def forward(self, x_i, x_j):
        x = x_i * x_j
        if x.dtype != self.lins[0].weight.dtype:
            x = x.float()
        for lin in self.lins[:-1]:
            x = lin(x)
            x = F.relu(x)
            x = F.dropout(x, p=self.dropout, training=self.training)
        x = self.lins[-1](x)
        return torch.sigmoid(x)
    
    def forward_diffusion(self, x_i, x_j):
        x = x_i * x_j
        if x.dtype != self.lins[0].weight.dtype:
            x = x.float()
        for lin in self.lins[:-1]:
            x = lin(x)
            x = F.relu(x)
        x = self.lins[-1](x)
        return x


class GNNLinkPredictor(torch.nn.Module):
    def __init__(self, gnn, predictor):
        super(GNNLinkPredictor, self).__init__()
        self.gnn = gnn
        self.predictor = predictor

    def reset_parameters(self):
        self.gnn.reset_parameters()
        self.predictor.reset_parameters()

    def forward(self, x, adj, edge=None):
        if hasattr(self.gnn, "n_steps"):
            out = self.gnn(adj, self.gnn.num_nodes)
        else:
            out = self.gnn(x, adj)
        if edge is not None:
            out = self.predictor(out[edge[0]], out[edge[1]])
        return out