from diffusion import *
from link_predictor import *


# Return network & file name
def getNetwork(data, args):
    num_feat = data.num_features
    gnn_type = args.gnn_type
    depth = args.depth

    if args.dataset.startswith('ogbl'):        
        if gnn_type=='OURS':
            gnn = OurLearner(in_feat=num_feat, h_dim=args.hidden, out_feat=args.out_feat, num_layers=depth, dropout=args.dropout, dataset=data)
            predictor = LinkPredictor(args.out_feat, args.pred_hidden, 1, args.mlp_num_layers, args.dropout)
            net = GraphDiffusion(gnn=gnn, predictor=predictor, data=data, args=args)
            file_name = 'GraphDissipation_{}_{}_{}lyr'.format(args.gnn_type, args.hidden, args.depth)
    return net, file_name