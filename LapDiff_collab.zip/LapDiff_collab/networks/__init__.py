from .model.dissipation_backup2 import GraphDiffusion, OurLearner
from .model.link_predictor import LinkPredictor